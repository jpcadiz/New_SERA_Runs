# USA-Sample-Test-Large-SupDemCurve-ANNon

12/05/23

This is a made up test case which utilizes each of the SERA model updates completed in the Summer 2023. **The results from this example test case should in no way be used to inform hydrogen investment or policy decisions.** Only the scenario.yaml file structure and input file structures should be referenced for helping new SERA users understand how to develop their own run cases.

